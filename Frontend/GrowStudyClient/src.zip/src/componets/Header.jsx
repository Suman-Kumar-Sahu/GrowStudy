import React, { useContext, useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import api from "../api/Axios";

export default function Header() {
  const { user, setUser } = useContext(AuthContext);
  const navigate = useNavigate();
  const location = useLocation();
  const [notifCount, setNotifCount] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => { setMenuOpen(false); }, [location.pathname]);

  useEffect(() => {
    if (user?.role !== "student") return;
    api.get("/notify/student/messages").then(res => {
      setNotifCount(res.data.filter(m => m.status !== "pending" && !m.isRead).length);
    }).catch(() => {});
  }, [user]);

  useEffect(() => {
    if (location.pathname !== "/student/messages") return;
    setNotifCount(0);
    api.put("/notify/mark-read", {}).catch(() => {});
  }, [location.pathname]);

  const handleLogout = async () => {
    try { await api.post("/auth/user/logout"); } catch {}
    setUser(null);
    navigate("/user/login");
  };

  const isActive = (path) => location.pathname === path;

  return (
    <>
      <header style={{
        position:"sticky", top:0, zIndex:100,
        backdropFilter:"blur(20px) saturate(180%)",
        background:"rgba(6,9,26,0.85)",
        borderBottom:"1px solid var(--border)"
      }}>
        <div style={{
          maxWidth:1280, margin:"0 auto",
          display:"flex", alignItems:"center", justifyContent:"space-between",
          padding:"0 24px", height:64
        }}>
          <Link to="/" style={{ display:"flex", alignItems:"center", gap:10, textDecoration:"none" }}>
            <div style={{
              width:32, height:32, borderRadius:8,
              background:"linear-gradient(135deg, var(--cyan), var(--cyan-d))",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontWeight:800, fontSize:13, color:"var(--bg-base)", fontFamily:"var(--font-ui)"
            }}>CN</div>
            <span style={{ fontFamily:"var(--font-serif)", fontSize:"1.4rem", fontStyle:"italic", color:"var(--text-1)" }}>
              CareerNest
            </span>
          </Link>

          {/* Desktop */}
          <nav className="header-desktop-nav">
            {user?.role === "student" && (<>
              <HeaderLink to="/jobs" active={isActive("/jobs")}>Explore Jobs</HeaderLink>
              <HeaderLink to="/student/dashboard" active={isActive("/student/dashboard")}>Dashboard</HeaderLink>
              <HeaderLink to="/profile" active={isActive("/profile")}>Profile</HeaderLink>
              <Link to="/student/messages" className="header-bell">
                🔔
                {notifCount > 0 && <span className="header-bell-badge">{notifCount}</span>}
              </Link>
            </>)}
            {user?.role === "recruiter" && (<>
              <HeaderLink to="/recruiter" active={isActive("/recruiter")}>Dashboard</HeaderLink>
              <HeaderLink to="/recruiter/applications" active={isActive("/recruiter/applications")}>Applicants</HeaderLink>
              <HeaderLink to="/profile" active={isActive("/profile")}>Profile</HeaderLink>
            </>)}
            {user
              ? <button onClick={handleLogout} className="cn-btn cn-btn-ghost cn-btn-sm" style={{marginLeft:8}}>Logout</button>
              : (<>
                  <HeaderLink to="/user/login" active={isActive("/user/login")}>Login</HeaderLink>
                  <Link to="/user/register" className="cn-btn cn-btn-primary cn-btn-sm" style={{marginLeft:8,textDecoration:"none"}}>
                    Register Free
                  </Link>
                </>)
            }
          </nav>

          {/* Mobile toggle */}
          <button className="header-hamburger" onClick={() => setMenuOpen(p => !p)}>
            {menuOpen ? "✕" : "☰"}
          </button>
        </div>

        {menuOpen && (
          <div className="header-mobile-menu">
            {user?.role === "student" && (<>
              <MobileNavLink to="/jobs" onClick={() => setMenuOpen(false)}>Explore Jobs</MobileNavLink>
              <MobileNavLink to="/student/dashboard" onClick={() => setMenuOpen(false)}>Dashboard</MobileNavLink>
              <MobileNavLink to="/student/messages" onClick={() => setMenuOpen(false)}>
                Messages {notifCount > 0 && `(${notifCount})`}
              </MobileNavLink>
            </>)}
            {user?.role === "recruiter" && (<>
              <MobileNavLink to="/recruiter" onClick={() => setMenuOpen(false)}>Dashboard</MobileNavLink>
              <MobileNavLink to="/recruiter/applications" onClick={() => setMenuOpen(false)}>Applicants</MobileNavLink>
            </>)}
            <MobileNavLink to="/profile" onClick={() => setMenuOpen(false)}>Profile</MobileNavLink>
            {user
              ? <button onClick={handleLogout} className="mobile-logout-btn">Logout</button>
              : <MobileNavLink to="/user/login" onClick={() => setMenuOpen(false)}>Login</MobileNavLink>
            }
          </div>
        )}
      </header>

      <style>{`
        .header-desktop-nav { display:flex; align-items:center; gap:4px; }
        .header-hamburger { display:none; background:none; border:none; color:var(--text-1); cursor:pointer; font-size:22px; padding:4px 8px; }
        .header-bell { position:relative; width:38px; height:38px; border-radius:10px; border:1px solid var(--border); background:var(--bg-raised); display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--text-2); text-decoration:none; font-size:15px; transition:all 0.2s; }
        .header-bell:hover { border-color:var(--border-glow); color:var(--cyan); }
        .header-bell-badge { position:absolute; top:-4px; right:-4px; width:18px; height:18px; border-radius:50%; background:var(--red); border:2px solid var(--bg-base); font-size:9px; font-weight:700; color:#fff; display:flex; align-items:center; justify-content:center; }
        .header-mobile-menu { border-top:1px solid var(--border); background:var(--bg-surface); padding:12px 24px 20px; }
        .mobile-logout-btn { margin-top:8px; padding:11px 0; color:var(--red); background:none; border:none; font-family:var(--font-ui); font-size:15px; font-weight:600; cursor:pointer; display:block; width:100%; text-align:left; }
        @media (max-width:768px) { .header-desktop-nav { display:none !important; } .header-hamburger { display:block !important; } }
      `}</style>
    </>
  );
}

function HeaderLink({ to, active, children }) {
  return (
    <Link to={to} style={{
      padding:"7px 14px", borderRadius:8, textDecoration:"none",
      color: active ? "var(--cyan)" : "var(--text-2)",
      background: active ? "var(--bg-raised)" : "transparent",
      fontSize:14, fontWeight:500, transition:"all 0.2s"
    }}>{children}</Link>
  );
}
function MobileNavLink({ to, onClick, children }) {
  return (
    <Link to={to} onClick={onClick} style={{
      display:"block", padding:"12px 0", borderBottom:"1px solid var(--border)",
      color:"var(--text-2)", textDecoration:"none", fontSize:15, fontWeight:500
    }}>{children}</Link>
  );
}
