import { createContext, useState, useEffect } from "react";
import api from "../api/Axios";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // AUTO LOGIN (SESSION RESTORE)
  useEffect(() => {
    const restoreSession = async () => {
      try {
        // Fixed: added leading slash to API path
        const res = await api.get("/auth/user/me");
        setUser(res.data);
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    restoreSession();
  }, []);

  return (
    <AuthContext.Provider value={{ user, setUser, loading }}>
      {children}
    </AuthContext.Provider>
  );
};