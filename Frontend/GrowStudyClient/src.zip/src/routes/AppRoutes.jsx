import React, { useContext } from "react";
import { Routes, Route, Navigate, Outlet } from "react-router-dom";
import { AuthContext } from "../context/AuthContext.jsx";

// Pages
import Home from "../pages/Home.jsx";
import Login from "../pages/Login.jsx";
import Register from "../pages/Register.jsx";
import Profile from "../pages/Profile.jsx";
import JobList from "../pages/JobList.jsx";
import RecruiterDashboard from "../pages/RecruiterDashboard.jsx";
import StudentDashboard from "../pages/StudentDashboard.jsx";
import RecruiterApplications from "../pages/RecruiterApplications.jsx";
import StudentMessages from "../pages/StudentMessages.jsx";
import NotFound from "../pages/NotFound.jsx";
import ProfileVisit from "../pages/ProfileVisit.jsx";

// Layout
import Layout from "../layout/Layout.jsx";

// ─── Route Guards (defined OUTSIDE component to prevent re-mounting) ───────────

/**
 * Wraps authenticated routes. Redirects to /user/login if not logged in.
 */
function ProtectedRoute() {
  const { user, loading } = useContext(AuthContext);
  if (loading) return null; // handled by parent loader
  if (!user) return <Navigate to="/user/login" replace />;
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
}

/**
 * Role-gated route. Redirects unauthenticated users to login,
 * wrong-role users to home.
 */
function RoleRoute({ role }) {
  const { user } = useContext(AuthContext);
  if (!user) return <Navigate to="/user/login" replace />;
  if (user.role !== role) return <Navigate to="/" replace />;
  return <Outlet />;
}

/**
 * Public-only route. If already logged in, redirects to role dashboard.
 */
function PublicRoute({ children }) {
  const { user } = useContext(AuthContext);
  if (user) {
    const redirectPath = user.role === "recruiter" ? "/recruiter" : "/jobs";
    return <Navigate to={redirectPath} replace />;
  }
  return children;
}

// ─── App Routes ────────────────────────────────────────────────────────────────

export default function AppRoutes() {
  const { loading } = useContext(AuthContext);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-indigo-600 font-medium">Loading CareerNest…</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Home />} />
      <Route
        path="/user/login"
        element={
          <PublicRoute>
            <Login />
          </PublicRoute>
        }
      />
      <Route
        path="/user/register"
        element={
          <PublicRoute>
            <Register />
          </PublicRoute>
        }
      />

      {/* Protected Routes */}
      <Route element={<ProtectedRoute />}>
        <Route path="/profile" element={<Profile />} />
        <Route path="/profile/:id" element={<ProfileVisit />} />

        {/* Student-only Routes */}
        <Route element={<RoleRoute role="student" />}>
          <Route path="/jobs" element={<JobList />} />
          <Route path="/student/dashboard" element={<StudentDashboard />} />
          <Route path="/student/messages" element={<StudentMessages />} />
        </Route>

        {/* Recruiter-only Routes */}
        <Route element={<RoleRoute role="recruiter" />}>
          <Route path="/recruiter" element={<RecruiterDashboard />} />
          <Route path="/recruiter/applications" element={<RecruiterApplications />} />
        </Route>
      </Route>

      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}