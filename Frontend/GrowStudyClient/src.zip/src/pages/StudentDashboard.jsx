import React, { useState, useEffect, useRef, useContext } from "react";
import api from "../api/Axios";
import { AuthContext } from "../context/AuthContext";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const STATUS_CONFIG = {
  pending:  { label:"Pending",    color:"var(--amber)", bg:"rgba(245,158,11,0.1)", border:"rgba(245,158,11,0.2)", dot:"var(--amber)" },
  reviewed: { label:"Reviewed",   color:"var(--cyan)",  bg:"rgba(34,211,238,0.1)", border:"rgba(34,211,238,0.2)", dot:"var(--cyan)" },
  selected: { label:"Shortlisted",color:"var(--green)", bg:"rgba(16,185,129,0.1)", border:"rgba(16,185,129,0.2)", dot:"var(--green)" },
  rejected: { label:"Not selected",color:"var(--red)",  bg:"rgba(244,63,94,0.1)", border:"rgba(244,63,94,0.2)",   dot:"var(--red)" },
};

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status?.toLowerCase()] || STATUS_CONFIG.pending;
  return (
    <span style={{
      display:"inline-flex", alignItems:"center", gap:6,
      padding:"5px 10px", borderRadius:6,
      background:cfg.bg, border:`1px solid ${cfg.border}`,
      fontSize:12, fontWeight:600, color:cfg.color
    }}>
      <span style={{ width:5, height:5, borderRadius:"50%", background:cfg.dot, display:"block" }} />
      {cfg.label}
    </span>
  );
}

export default function StudentDashboard() {
  const { user } = useContext(AuthContext);
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const prevAppsRef = useRef([]);

  const fetchApplications = async () => {
    try {
      const res = await api.get("/applications/student");
      const apps = res.data.applications || res.data;

      // Notify on status changes (avoids stale closure by using ref)
      apps.forEach(app => {
        const old = prevAppsRef.current.find(a => a._id === app._id);
        if (old && old.status !== app.status) {
          toast.info(`"${app.jobId?.title}" status changed to ${app.status}`);
        }
      });
      prevAppsRef.current = apps;
      setApplications(apps);
    } catch {
      toast.error("Failed to load applications");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
    const interval = setInterval(fetchApplications, 15000);
    return () => clearInterval(interval);
  }, []);

  const counts = {
    total: applications.length,
    pending: applications.filter(a => a.status === "pending").length,
    reviewed: applications.filter(a => a.status === "reviewed").length,
    selected: applications.filter(a => a.status === "selected").length,
  };

  if (loading) return (
    <div className="cn-loading-screen">
      <div className="cn-spinner" />
      <p style={{ color:"var(--text-3)", fontSize:14 }}>Loading your applications...</p>
    </div>
  );

  return (
    <div className="cn-page" style={{ paddingTop:40, paddingBottom:80 }}>
      <ToastContainer position="top-right" autoClose={3000} theme="dark" />

      <div style={{ marginBottom:32 }}>
        <span className="cn-section-label">Your activity</span>
        <h1 className="cn-section-title" style={{ display:"block", marginTop:4 }}>
          Good morning, <em>{user?.name?.split(" ")[0] || "there"}</em> 👋
        </h1>
      </div>

      {/* Stats */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:16, marginBottom:28 }} className="stats-grid">
        {[
          { icon:"📩", num:counts.total, label:"Applications sent" },
          { icon:"👁️", num:counts.reviewed, label:"Under review" },
          { icon:"🏆", num:counts.selected, label:"Shortlisted" },
          { icon:"⏳", num:counts.pending, label:"Awaiting response" },
        ].map(({ icon, num, label }) => (
          <div key={label} className="cn-card" style={{ padding:22 }}>
            <div style={{ fontSize:22, marginBottom:8 }}>{icon}</div>
            <div style={{ fontFamily:"var(--font-serif)", fontStyle:"italic", fontSize:"2.2rem", color:"var(--text-1)", lineHeight:1 }}>{num}</div>
            <div style={{ fontSize:13, color:"var(--text-3)", marginTop:6 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Applications List */}
      <div style={{
        background:"var(--bg-surface)", border:"1px solid var(--border)",
        borderRadius:"var(--r-lg)", overflow:"hidden"
      }}>
        <div style={{
          padding:"20px 24px", borderBottom:"1px solid var(--border)",
          display:"flex", alignItems:"center", justifyContent:"space-between"
        }}>
          <h2 style={{ fontSize:16, fontWeight:700 }}>My Applications</h2>
          <span className="cn-tag cn-tag-gray">{counts.total} total</span>
        </div>

        {applications.length === 0 ? (
          <div style={{ padding:64, textAlign:"center" }}>
            <div style={{ fontSize:56, marginBottom:16 }}>📭</div>
            <h3 style={{ fontSize:18, fontWeight:700, color:"var(--text-1)", marginBottom:8 }}>No applications yet</h3>
            <p style={{ color:"var(--text-3)", fontSize:14 }}>Start applying to jobs to track your progress here.</p>
          </div>
        ) : (
          <div style={{ padding:16, display:"flex", flexDirection:"column", gap:10 }}>
            {applications.map(app => (
              <div key={app._id} style={{
                display:"flex", alignItems:"center", gap:16,
                padding:"16px 20px", borderRadius:"var(--r)",
                background:"var(--bg-raised)", border:"1px solid var(--border)",
                transition:"all 0.2s"
              }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "var(--border-glow)"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "var(--border)"; }}
              >
                <div style={{
                  width:40, height:40, borderRadius:10,
                  background:"rgba(34,211,238,0.1)", border:"1px solid rgba(34,211,238,0.2)",
                  display:"flex", alignItems:"center", justifyContent:"center",
                  fontWeight:800, color:"var(--cyan)", fontSize:15, flexShrink:0
                }}>
                  {(app.jobId?.company || "?")[0].toUpperCase()}
                </div>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:15, color:"var(--text-1)" }}>
                    {app.jobId?.title || "Untitled Job"}
                  </div>
                  <div style={{ fontSize:13, color:"var(--text-3)" }}>
                    {app.jobId?.company || "N/A"} · {app.jobId?.skillsRequired?.join(", ") || "N/A"}
                  </div>
                </div>
                <StatusBadge status={app.status} />
              </div>
            ))}
          </div>
        )}
      </div>

      <style>{`
        @media (max-width:768px) { .stats-grid { grid-template-columns:1fr 1fr !important; } }
        @media (max-width:480px) { .stats-grid { grid-template-columns:1fr !important; } }
      `}</style>
    </div>
  );
}
